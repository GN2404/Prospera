/* ============================================
   PROSPERA — Main JavaScript
   Nav, Carousel, Scroll Animations (Intersection
   Observer), FAQ Accordion, Form Validation
   ============================================ */

document.addEventListener('DOMContentLoaded', () => {

  /* ------------------------------------------
     1. SCROLL REVEAL (Intersection Observer)
     Adds .visible to .fade-in elements when
     they enter the viewport.
  ------------------------------------------ */
  const fadeEls = document.querySelectorAll('.fade-in');
  if (fadeEls.length > 0) {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            observer.unobserve(entry.target); // animate once
          }
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -30px 0px' }
    );
    fadeEls.forEach(el => observer.observe(el));
  }


  /* ------------------------------------------
     2. NAVBAR — shadow on scroll
  ------------------------------------------ */
  const navbar = document.querySelector('.navbar');
  if (navbar) {
    window.addEventListener('scroll', () => {
      navbar.style.boxShadow = window.scrollY > 10
        ? '0 1px 8px rgba(0,0,0,0.1)'
        : '0 1px 3px rgba(0,0,0,0.08)';
    });
  }


  /* ------------------------------------------
     3. MOBILE HAMBURGER MENU
  ------------------------------------------ */
  const hamburger = document.querySelector('.navbar__hamburger');
  const mobileNav = document.querySelector('.navbar__mobile');

  if (hamburger && mobileNav) {
    hamburger.addEventListener('click', () => {
      hamburger.classList.toggle('navbar__hamburger--open');
      mobileNav.classList.toggle('navbar__mobile--open');
      document.body.style.overflow =
        mobileNav.classList.contains('navbar__mobile--open') ? 'hidden' : '';
    });
    // Close on link click
    mobileNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        hamburger.classList.remove('navbar__hamburger--open');
        mobileNav.classList.remove('navbar__mobile--open');
        document.body.style.overflow = '';
      });
    });
  }


  /* ------------------------------------------
     4. DASHBOARD CAROUSEL
     Auto-advances every 4s, manual prev/next
     and dot navigation.
  ------------------------------------------ */
  const carousel = document.querySelector('.carousel');
  if (carousel) {
    const slides = carousel.querySelector('.carousel__slides');
    const dots = carousel.querySelectorAll('.carousel__dot');
    const prevBtn = carousel.querySelector('.carousel__btn--prev');
    const nextBtn = carousel.querySelector('.carousel__btn--next');
    const total = carousel.querySelectorAll('.carousel__slide').length;
    let current = 0;
    let timer;

    function goTo(i) {
      if (i >= total) i = 0;
      if (i < 0) i = total - 1;
      current = i;
      slides.style.transform = `translateX(-${current * 100}%)`;
      dots.forEach((d, idx) => d.classList.toggle('carousel__dot--active', idx === current));
    }

    function startAuto() { timer = setInterval(() => goTo(current + 1), 4000); }
    function resetAuto() { clearInterval(timer); startAuto(); }

    if (nextBtn) nextBtn.addEventListener('click', () => { goTo(current + 1); resetAuto(); });
    if (prevBtn) prevBtn.addEventListener('click', () => { goTo(current - 1); resetAuto(); });
    dots.forEach((d, i) => d.addEventListener('click', () => { goTo(i); resetAuto(); }));

    startAuto();
  }


  /* ------------------------------------------
     5. FAQ ACCORDION
  ------------------------------------------ */
  document.querySelectorAll('.faq-item').forEach(item => {
    const btn = item.querySelector('.faq-question');
    const ans = item.querySelector('.faq-answer');

    btn.addEventListener('click', () => {
      const isOpen = item.classList.contains('faq-item--open');

      // Close all
      document.querySelectorAll('.faq-item').forEach(other => {
        other.classList.remove('faq-item--open');
        other.querySelector('.faq-answer').style.maxHeight = null;
      });

      // Toggle this
      if (!isOpen) {
        item.classList.add('faq-item--open');
        ans.style.maxHeight = ans.scrollHeight + 'px';
      }
    });
  });


  /* ------------------------------------------
     6. SIGN UP FORM VALIDATION
  ------------------------------------------ */
  const signupForm = document.getElementById('signupForm');
  if (signupForm) {
    const success = document.getElementById('signupSuccess');

    signupForm.addEventListener('submit', e => {
      e.preventDefault();
      let valid = true;

      // Reset
      signupForm.querySelectorAll('.form-group').forEach(g => g.classList.remove('form-group--error'));
      signupForm.querySelectorAll('.form-input,.form-select').forEach(i => i.classList.remove('form-input--error'));

      // Required check
      signupForm.querySelectorAll('[required]').forEach(f => {
        if (!f.value.trim()) { markError(f, 'This field is required.'); valid = false; }
      });

      // Email regex
      const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      signupForm.querySelectorAll('input[type="email"]').forEach(f => {
        if (f.value.trim() && !emailRe.test(f.value.trim())) {
          markError(f, 'Please enter a valid email address.'); valid = false;
        }
      });

      // Password length
      const pw = signupForm.querySelector('#password');
      if (pw && pw.value.length > 0 && pw.value.length < 8) {
        markError(pw, 'Password must be at least 8 characters.'); valid = false;
      }

      // Password match
      const cpw = signupForm.querySelector('#confirmPassword');
      if (pw && cpw && pw.value !== cpw.value) {
        markError(cpw, 'Passwords do not match.'); valid = false;
      }

      if (valid) {
        signupForm.style.display = 'none';
        if (success) success.classList.add('form-success--show');
      }
    });

    // Live clear on blur
    signupForm.querySelectorAll('.form-input,.form-select').forEach(f => {
      f.addEventListener('blur', () => {
        if (f.value.trim()) {
          const g = f.closest('.form-group');
          if (g) { g.classList.remove('form-group--error'); f.classList.remove('form-input--error'); }
        }
      });
    });
  }

  function markError(field, msg) {
    const g = field.closest('.form-group');
    if (g) {
      g.classList.add('form-group--error');
      field.classList.add('form-input--error');
      const err = g.querySelector('.form-error');
      if (err) err.textContent = msg;
    }
  }


  /* ------------------------------------------
     7. WAITLIST FORM
  ------------------------------------------ */
  const wlForm = document.getElementById('waitlistForm');
  if (wlForm) {
    const wlSuccess = document.getElementById('waitlistSuccess');
    wlForm.addEventListener('submit', e => {
      e.preventDefault();
      const email = wlForm.querySelector('input[type="email"]');
      if (email && email.value.trim()) {
        wlForm.style.display = 'none';
        if (wlSuccess) wlSuccess.classList.add('form-success--show');
        // Bump counter
        const num = document.querySelector('.waitlist-counter__num');
        if (num) {
          const n = parseInt(num.textContent.replace(/,/g, ''));
          num.textContent = (n + 1).toLocaleString();
        }
      }
    });
  }


  /* ------------------------------------------
     8. LOGIN MODAL
  ------------------------------------------ */
  const loginOverlay = document.getElementById('loginModal');
  if (loginOverlay) {
    document.querySelectorAll('[data-open-login]').forEach(btn => {
      btn.addEventListener('click', e => { e.preventDefault(); loginOverlay.classList.add('modal-overlay--show'); });
    });
    const closeBtn = loginOverlay.querySelector('.modal__close');
    if (closeBtn) closeBtn.addEventListener('click', () => loginOverlay.classList.remove('modal-overlay--show'));
    loginOverlay.addEventListener('click', e => {
      if (e.target === loginOverlay) loginOverlay.classList.remove('modal-overlay--show');
    });
  }

});
